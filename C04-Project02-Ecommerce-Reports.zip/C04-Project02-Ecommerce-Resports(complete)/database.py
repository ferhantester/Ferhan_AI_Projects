from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider

# AstraDB Client and Secret required for the connection
ASTRA_CLIENT_ID = 'GoEiSAZIfZMSeMiSMKbdIWka'
ASTRA_SECRET = 'WIiWgl-1Zx9iudc,,P-pikw77ZpzHf5GzHaytaOP4CJufef,wSdOvs,JnLTAl-B1WL77Ho-i4NHxNflHeCrBImJhH9jKR1Q9PTUiUqaz4aaOrNFb1lawlh0zkKX9r456'

# Cloud Configuration
cloud_config = {
    'secure_connect_bundle': 'connect_bundle/secure-connect-e-commerce-db.zip'
}

# Authentication Provider
auth_provider = PlainTextAuthProvider(ASTRA_CLIENT_ID, ASTRA_SECRET)

# session object which is used for interacting with Cassandra database
session = None


# Method for creating session object based on cloud configuration and Auth Provider
def create_session():
    global session
    try:
        if session is None:
            # cluster object as per cloud configuration and auth_provider
            cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)

            # Session object
            session = cluster.connect()

            print("Session is successfully initiated")

    except Exception as e:
        print("Error in initialising session", str(e))
        return None

    else:
        return session

# Method for setting keyspace in the session
# Input Parameters:
#    Session object
#    Keyspace_name


def set_session_keyspace(session1, keyspace_name):
    try:
        # Setting keyspace in the Cassandra session
        session1.execute(f'USE {keyspace_name}')

    except Exception as e:
        print("Error in setting keyspace in the session", str(e))

    else:
        print(f'{keyspace_name} keyspace is set in the session')

# Method for executing query using the given session object
# Input Parameters:
#    Session object
#    query for execution


def execute_query(session1, query):
    try:
        return session1.execute(query)

    except Exception as e:
        print("Error in executing the query:", str(e))

# Method for executing single row query using the given session object
# Input Parameters:
#    Session object
#    query for execution


def execute_single_row_query(session1, query):
    try:
        return session1.execute(query).one()

    except Exception as e:
        print("Error in executing the query:", str(e))


# Method for fetching table data using the given session object
# Input Parameters:
#    Session object
#    table name for which the data is to be fetched


def show_table_data(session1, table_name):
    _ = None
    try:
        _ = session1.execute(f"SELECT * FROM {table_name}")

    except Exception as e:
        print("Error in fetching data from the table", str(e))

    else:
        for row in _:
            print(row)
