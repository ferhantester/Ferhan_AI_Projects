import csv


class System:
    def __init__(self):
        self.sensors_list = list()
        self.sensor_mapping_list = list()
        self.master_node_list = list()
        
    def config_system(self, file):
        data_file = open(file, 'r')
        reader = csv.DictReader(data_file)
        for row in reader:
            node_id = row['Node ID']
            type1 = row['Type']
            master_node_id = row['Master Node ID']
            
            if type1 == 'Master':
                self.master_node_list.append(int(master_node_id))
            elif type1 == "Sensor":
                self.sensors_list.append(int(node_id))
                self.sensor_mapping_list.append(int(master_node_id))

    @staticmethod
    def sensor_assigned_count(mapping_list, low, high, overload_sensor):
        count = 0
        for i in range(low, high + 1):
            if mapping_list[i] == overload_sensor:
                count += 1
        return count

    def overload_node_helper(self, low, high):
        if low == high:
            return self.sensor_mapping_list[low]

        mid = (low + high) // 2

        left_overload_node = self.overload_node_helper(low, mid)
        right_overload_node = self.overload_node_helper(mid + 1, high)

        # Use the class name to call the static method
        left_count = System.sensor_assigned_count(self.sensor_mapping_list, low, high, left_overload_node)
        right_count = System.sensor_assigned_count(self.sensor_mapping_list, low, high, right_overload_node)

        return left_overload_node if left_count > right_count else right_overload_node

    def get_overloaded_node(self):
        return self.overload_node_helper(0, len(self.sensor_mapping_list) - 1)

    def get_potential_overload_node(self):
        n = len(self.sensors_list)
        potential_overload_nodes = set()

        for sensor_id in set(self.sensors_list):
            # Use the class name to call the static method
            count = System.sensor_assigned_count(self.sensor_mapping_list, 0, n - 1, sensor_id)
            if n // 3 <= count < n // 2:
                potential_overload_nodes.add(sensor_id)

        return potential_overload_nodes


if __name__ == "__main__":
    test_system1 = System()
    
    test_system1.config_system('app_data1.csv')

    print("Overloaded Master Node : ", test_system1.get_overloaded_node())
    
    print("Partially Overloaded Master Node : ", test_system1.get_potential_overload_node())

    test_system2 = System()
    
    test_system2.config_system('app_data2.csv')
    
    print("Overloaded Master Node : ", test_system2.get_overloaded_node())
    
    print("Partially Overloaded Master Node : ", test_system2.get_potential_overload_node())

    test_system3 = System()

    test_system3.config_system('app_data3.csv')
    
    print("Overloaded Master Node : ", test_system3.get_overloaded_node())
    
    print("Partially Overloaded Master Node : ", test_system3.get_potential_overload_node())

    test_system4 = System()

    test_system4.config_system('app_data4.csv')
    
    print("Overloaded Master Node : ", test_system4.get_overloaded_node())
    
    print("Partially Overloaded Master Node : ", test_system4.get_potential_overload_node())
